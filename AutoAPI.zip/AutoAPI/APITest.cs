using static RestAssured.Dsl;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NUnit.Framework;

namespace AutoAPI
{
    public class Tests
    {
        private readonly string Baseurl = "https://api.restful-api.dev/objects";
        private static readonly string jsonListFilePath = "./../../../Assets/ObjectList.json";
        private static readonly string SingleJsonFilePath = "./../../../Assets/SingleObject.json";
        private static readonly string NewObjectFilePath = "./../../../Assets/NewObject.json";
        private static readonly string UpdateObjectFilePath = "./../../../Assets/UpdateObject.json";
        private static JToken GetJsonArrayAsString(string filePath)
        {
            string json = File.ReadAllText(filePath);

            JArray jsonArray = JArray.Parse(json);
            return jsonArray.ToString(Formatting.None);
        }

        public static JToken GetJsonContentAsString(string filePath)
        {
            string json = File.ReadAllText(filePath);

            JObject jsonObject = JObject.Parse(json);
            return jsonObject.ToString(Formatting.None);
        }


        [Test]
        public void GetObjectList()
        {
            _ = Given()
            .When()
            .Get(Baseurl)
            .Then()
            .StatusCode(200)
            .ContentType("application/json")
            .Body($"{GetJsonArrayAsString(jsonListFilePath)}");
        }

        [Test]
        public void GetObjectById()
        {
            _ = Given()
            .When()
            .PathParam("id", 1)
            .Get($"{Baseurl}/[id]")
            .Then()
            .StatusCode(200)
            .ContentType("application/json")
            .Body($"{GetJsonContentAsString(SingleJsonFilePath)}");
        }

        [Test]
        public void CreateObject()
        {
            _ = Given()
            
            .When()
            .Post(Baseurl)
            .Then()
            .StatusCode(200)
            .ContentType("application/json")
            .Body(File.ReadAllText(NewObjectFilePath));
        }

        [Test]
        public void UpdateObject()
        {
            _ = Given()
            .When()
            .PathParam("id", 1)
            .Patch($"{Baseurl}/[id]")
            .Then()
            .StatusCode(405)
            .ContentType("application/json")
            .Body(File.ReadAllText(UpdateObjectFilePath));
        }


        [Test]
        public void DeleteObject()
        {
            _ = Given()
            .When()
            .PathParam("id", 10)
            .Delete($"{Baseurl}/[id]")
            .Then()
            .StatusCode(405)
            .ContentType("application/json");
        }
    }
}
